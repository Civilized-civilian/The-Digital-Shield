
import { db } from "./db";
import {
  gameQuestions,
  chatMessages,
  type GameQuestion,
  type ChatMessage,
  type InsertChatMessage,
} from "@shared/schema";
import { eq, sql } from "drizzle-orm";

export interface IStorage {
  // Game
  getGameQuestions(): Promise<GameQuestion[]>;
  getGameQuestion(id: number): Promise<GameQuestion | undefined>;
  seedGameQuestions(): Promise<void>;

  // Chat
  saveChatMessage(message: InsertChatMessage): Promise<ChatMessage>;
  getChatHistory(sessionId: string): Promise<ChatMessage[]>;
}

export class DatabaseStorage implements IStorage {
  async getGameQuestions(): Promise<GameQuestion[]> {
    // Return all questions (or random subset in future)
    return await db.select().from(gameQuestions);
  }

  async getGameQuestion(id: number): Promise<GameQuestion | undefined> {
    const [question] = await db
      .select()
      .from(gameQuestions)
      .where(eq(gameQuestions.id, id));
    return question;
  }

  async saveChatMessage(message: InsertChatMessage): Promise<ChatMessage> {
    const [saved] = await db
      .insert(chatMessages)
      .values(message)
      .returning();
    return saved;
  }

  async getChatHistory(sessionId: string): Promise<ChatMessage[]> {
    return await db
      .select()
      .from(chatMessages)
      .where(eq(chatMessages.sessionId, sessionId))
      .orderBy(chatMessages.createdAt); // Oldest first
  }

  async seedGameQuestions(): Promise<void> {
    const count = await db.select({ count: sql<number>`count(*)` }).from(gameQuestions);
    if (Number(count[0].count) > 0) return;

    const questions = [
      {
        content: "URGENT: Your bank account has been locked due to suspicious activity. Click here to verify your identity: http://bit.ly/secure-bank-login",
        type: "sms",
        isScam: true,
        explanation: "Banks never send shortened links (bit.ly) or ask you to verify identity via SMS links. Always log in directly through the official app or website.",
      },
      {
        content: "Hi Mom, I lost my phone and wallet. This is my friend's number. Can you send me $50 for a cab? I'm stranded.",
        type: "sms",
        isScam: true,
        explanation: "This is a classic 'Hi Mum' scam. Scammers impersonate family members in distress to get money quickly. Call the original number you have for them to verify.",
      },
      {
        content: "Your Netflix subscription payment failed. Please update your payment details here: https://netflix-secure-update.com/login",
        type: "email",
        isScam: true,
        explanation: "Look at the URL! It says 'netflix-secure-update.com', not 'netflix.com'. Scammers often register look-alike domains.",
      },
      {
        content: "Order #12345 confirmed. Your package will arrive tomorrow. Track here: https://www.amazon.com/orders/track",
        type: "email",
        isScam: false,
        explanation: "This looks safe. The URL is legitimate (amazon.com) and the message is informational without urgent threats.",
      },
      {
        content: "Google Security Alert: New sign-in on Windows. If this wasn't you, check activity.",
        type: "email",
        isScam: false,
        explanation: "This is a standard security notification. It doesn't ask for credentials directly or use a suspicious link.",
      },
      {
        content: "CONGRATULATIONS! You've won a $500 Walmart Gift Card! Claim now: www.walmart-giveaway-winner.xyz",
        type: "sms",
        isScam: true,
        explanation: "If it sounds too good to be true, it is. The URL is clearly fake (.xyz domain) and unsolicited prizes are a major red flag.",
      }
    ];

    await db.insert(gameQuestions).values(questions);
  }
}

export const storage = new DatabaseStorage();
