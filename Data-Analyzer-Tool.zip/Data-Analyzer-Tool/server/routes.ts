
import type { Express } from "express";
import { createServer, type Server } from "http";
import { storage } from "./storage";
import { api } from "@shared/routes";
import { z } from "zod";

export async function registerRoutes(
  httpServer: Server,
  app: Express
): Promise<Server> {

  // === GAME ROUTES ===

  app.get(api.game.listQuestions.path, async (req, res) => {
    const questions = await storage.getGameQuestions();
    res.json(questions);
  });

  app.post(api.game.checkAnswer.path, async (req, res) => {
    const { questionId, userGuessedScam } = req.body;
    
    const question = await storage.getGameQuestion(questionId);
    if (!question) {
      return res.status(404).json({ message: "Question not found" });
    }

    const isCorrect = userGuessedScam === question.isScam;
    
    res.json({
      correct: isCorrect,
      explanation: question.explanation
    });
  });

  // === CHAT ROUTES ===

  app.get(api.chat.history.path, async (req, res) => {
    const { sessionId } = req.params;
    const history = await storage.getChatHistory(sessionId);
    res.json(history);
  });

  app.post(api.chat.send.path, async (req, res) => {
    const { message, sessionId } = req.body;

    // 1. Save user message
    await storage.saveChatMessage({
      sessionId,
      message,
      isBot: false
    });

    // 2. Generate rule-based response
    const lowerMsg = message.toLowerCase();
    let responseText = "I'm a demo bot. I can help you with 'phishing', 'deepfakes', 'passwords', or 'watermarking'. Try asking about those!";

    if (lowerMsg.includes("phishing") || lowerMsg.includes("scam")) {
      responseText = "Phishing is a cyber attack where scammers pretend to be trustworthy entities to steal your data. \n\nTip: Check the sender's email address and URL carefully before clicking links!";
    } else if (lowerMsg.includes("deepfake") || lowerMsg.includes("fake")) {
      responseText = "Deepfakes are AI-generated media that swap faces or voices to impersonate someone. \n\nWarning Signs: Unnatural blinking, mismatched audio, or blurry edges around the face.";
    } else if (lowerMsg.includes("password") || lowerMsg.includes("secure")) {
      responseText = "Strong passwords should be long (12+ chars), unique, and random. \n\nBest Practice: Use a Password Manager and enable Two-Factor Authentication (2FA) everywhere.";
    } else if (lowerMsg.includes("watermark") || lowerMsg.includes("protect") || lowerMsg.includes("creative")) {
      responseText = "To protect your creative work: \n1. Add visible watermarks. \n2. Use tools like 'Glaze' or 'Nightshade' to disrupt AI training. \n3. Register your copyright if possible.";
    } else if (lowerMsg.includes("help")) {
      responseText = "I can explain: \n- Phishing \n- Deepfakes \n- Password Security \n- Protecting Art \n\nJust type a topic!";
    }

    // 3. Save bot response
    await storage.saveChatMessage({
      sessionId,
      message: responseText,
      isBot: true
    });

    res.json({ response: responseText });
  });

  // Seed data on startup
  await storage.seedGameQuestions();

  return httpServer;
}
