
import { pgTable, text, serial, boolean, timestamp, integer } from "drizzle-orm/pg-core";
import { createInsertSchema } from "drizzle-zod";
import { z } from "zod";

// === TABLE DEFINITIONS ===

// Store game questions/scenarios in the database
export const gameQuestions = pgTable("game_questions", {
  id: serial("id").primaryKey(),
  content: text("content").notNull(), // The message content (email/SMS)
  type: text("type").notNull(), // 'email' or 'sms'
  isScam: boolean("is_scam").notNull(),
  explanation: text("explanation").notNull(), // Why it is/isn't a scam
});

// Store chat messages for history (optional but good for a full app)
export const chatMessages = pgTable("chat_messages", {
  id: serial("id").primaryKey(),
  sessionId: text("session_id").notNull(), // Simple session tracking
  message: text("message").notNull(),
  isBot: boolean("is_bot").notNull(),
  createdAt: timestamp("created_at").defaultNow(),
});

// === SCHEMAS ===
export const insertGameQuestionSchema = createInsertSchema(gameQuestions).omit({ id: true });
export const insertChatMessageSchema = createInsertSchema(chatMessages).omit({ id: true, createdAt: true });

// === TYPES ===
export type GameQuestion = typeof gameQuestions.$inferSelect;
export type ChatMessage = typeof chatMessages.$inferSelect;
export type InsertChatMessage = z.infer<typeof insertChatMessageSchema>;

// === API TYPES ===
export type ChatRequest = {
  message: string;
  sessionId: string;
};

export type ChatResponse = {
  response: string;
};

export type CheckAnswerRequest = {
  questionId: number;
  userGuessedScam: boolean;
};

export type CheckAnswerResponse = {
  correct: boolean;
  explanation: string;
};
