
import { z } from 'zod';
import { insertChatMessageSchema, gameQuestions } from './schema';

export const api = {
  game: {
    listQuestions: {
      method: 'GET' as const,
      path: '/api/game/questions' as const,
      responses: {
        200: z.array(z.custom<typeof gameQuestions.$inferSelect>()),
      },
    },
    checkAnswer: {
      method: 'POST' as const,
      path: '/api/game/check' as const,
      input: z.object({
        questionId: z.number(),
        userGuessedScam: z.boolean(),
      }),
      responses: {
        200: z.object({
          correct: z.boolean(),
          explanation: z.string(),
        }),
        404: z.object({ message: z.string() }),
      },
    },
  },
  chat: {
    send: {
      method: 'POST' as const,
      path: '/api/chat' as const,
      input: z.object({
        message: z.string(),
        sessionId: z.string(),
      }),
      responses: {
        200: z.object({
          response: z.string(),
        }),
      },
    },
    history: {
        method: 'GET' as const,
        path: '/api/chat/:sessionId' as const,
        responses: {
            200: z.array(z.custom<typeof insertChatMessageSchema & { id: number, createdAt: Date | null }>()),
        }
    }
  },
};

export function buildUrl(path: string, params?: Record<string, string | number>): string {
  let url = path;
  if (params) {
    Object.entries(params).forEach(([key, value]) => {
      if (url.includes(`:${key}`)) {
        url = url.replace(`:${key}`, String(value));
      }
    });
  }
  return url;
}
