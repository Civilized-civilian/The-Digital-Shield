## Packages
framer-motion | For smooth page transitions and interactive elements
lucide-react | For consistent, high-quality iconography

## Notes
Tailwind Config - extend fontFamily:
fontFamily: {
  sans: ["var(--font-sans)"],
  mono: ["var(--font-mono)"],
  display: ["var(--font-display)"],
}
