import { useQuery, useMutation, useQueryClient } from "@tanstack/react-query";
import { api, buildUrl } from "@shared/routes";
import { z } from "zod";

export function useQuestions() {
  return useQuery({
    queryKey: [api.game.listQuestions.path],
    queryFn: async () => {
      const res = await fetch(api.game.listQuestions.path, { credentials: "include" });
      if (!res.ok) throw new Error("Failed to fetch questions");
      return api.game.listQuestions.responses[200].parse(await res.json());
    },
  });
}

export function useCheckAnswer() {
  return useMutation({
    mutationFn: async (data: { questionId: number; userGuessedScam: boolean }) => {
      const res = await fetch(api.game.checkAnswer.path, {
        method: api.game.checkAnswer.method,
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify(data),
        credentials: "include",
      });
      if (!res.ok) {
        if (res.status === 404) throw new Error("Question not found");
        throw new Error("Failed to check answer");
      }
      return api.game.checkAnswer.responses[200].parse(await res.json());
    },
  });
}
