import { useQuery, useMutation, useQueryClient } from "@tanstack/react-query";
import { api, buildUrl } from "@shared/routes";
import { nanoid } from "nanoid";
import { useEffect, useState } from "react";

// Helper to get or create a session ID stored in localStorage
export function useSessionId() {
  const [sessionId, setSessionId] = useState<string>("");

  useEffect(() => {
    let stored = localStorage.getItem("chat_session_id");
    if (!stored) {
      stored = nanoid();
      localStorage.setItem("chat_session_id", stored);
    }
    setSessionId(stored);
  }, []);

  return sessionId;
}

export function useChatHistory(sessionId: string) {
  return useQuery({
    queryKey: [api.chat.history.path, sessionId],
    enabled: !!sessionId,
    queryFn: async () => {
      const url = buildUrl(api.chat.history.path, { sessionId });
      const res = await fetch(url, { credentials: "include" });
      if (!res.ok) throw new Error("Failed to fetch chat history");
      // Note: Backend might return dates as strings, we trust zod/react-query to handle it or standard JSON parsing
      // For strict typing with dates from JSON, we often need a transform, but here we'll rely on basic JSON
      const data = await res.json();
      return api.chat.history.responses[200].parse(data);
    },
  });
}

export function useSendMessage() {
  const queryClient = useQueryClient();
  
  return useMutation({
    mutationFn: async ({ message, sessionId }: { message: string; sessionId: string }) => {
      const res = await fetch(api.chat.send.path, {
        method: api.chat.send.method,
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({ message, sessionId }),
        credentials: "include",
      });
      
      if (!res.ok) throw new Error("Failed to send message");
      return api.chat.send.responses[200].parse(await res.json());
    },
    onSuccess: (_, variables) => {
      queryClient.invalidateQueries({ 
        queryKey: [api.chat.history.path, variables.sessionId] 
      });
    },
  });
}
