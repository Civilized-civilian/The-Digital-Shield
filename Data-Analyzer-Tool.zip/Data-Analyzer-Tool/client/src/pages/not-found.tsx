import { Link } from "wouter";
import { AlertTriangle } from "lucide-react";
import { Button } from "@/components/ui/button";

export default function NotFound() {
  return (
    <div className="min-h-screen w-full flex items-center justify-center bg-background text-foreground">
      <div className="text-center space-y-6 p-8">
        <div className="flex justify-center mb-4">
          <div className="p-4 rounded-full bg-destructive/10 text-destructive animate-pulse">
            <AlertTriangle className="w-16 h-16" />
          </div>
        </div>
        
        <h1 className="text-4xl md:text-6xl font-bold font-display">404 Error</h1>
        <p className="text-xl text-muted-foreground max-w-md mx-auto">
          The page you are looking for has been moved, deleted, or possibly abducted by aliens.
        </p>

        <div className="pt-4">
          <Link href="/">
            <Button size="lg" variant="default" className="bg-primary text-primary-foreground hover:bg-primary/90">
              Return Home
            </Button>
          </Link>
        </div>
      </div>
    </div>
  );
}
