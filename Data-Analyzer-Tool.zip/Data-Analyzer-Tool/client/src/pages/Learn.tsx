import { Navbar } from "@/components/Navbar";
import { Shield, UserX, Lock, FileWarning, CheckCircle, ArrowUp } from "lucide-react";
import { Button } from "@/components/ui/button";
import { motion } from "framer-motion";

export default function Learn() {
  const scrollToTop = () => {
    window.scrollTo({ top: 0, behavior: 'smooth' });
  };

  return (
    <div className="min-h-screen bg-background cyber-grid">
      <Navbar />
      
      <div className="container mx-auto px-4 lg:px-8 py-12">
        <div className="grid lg:grid-cols-[1fr_300px] gap-12">
          
          {/* Main Content */}
          <main className="space-y-16">
            <header className="space-y-4">
              <h1 className="text-4xl md:text-5xl font-bold font-display text-glow">
                Knowledge Base
              </h1>
              <p className="text-xl text-muted-foreground">
                Understanding the threats is the first step to neutralising them.
              </p>
            </header>

            <Section 
              id="identity"
              icon={Shield}
              title="What is Digital Identity?"
              content="Your digital identity is more than just your username and password. It encompasses your biometric data, browsing history, financial records, and social interactions. In the modern web, this data is often fragmented across hundreds of services, making it vulnerable to aggregation attacks where hackers piece together a complete profile from small data leaks."
            />

            <Section 
              id="deepfakes"
              icon={UserX}
              title="Deepfakes and AI Impersonation"
              content="Generative AI can now clone voices with just 3 seconds of audio and create realistic video overlays in real-time. Criminals use this for 'grandparent scams' or CEO fraud, where they impersonate a trusted figure to demand urgent money transfers. Always verify urgent requests through a second channel (e.g., call them back on a known number)."
            />

            <Section 
              id="phishing"
              icon={FileWarning}
              title="Phishing Attacks 2.0"
              content="Modern phishing isn't just poorly spelled emails. Spear-phishing uses AI to write personalized, context-aware messages referencing your recent job changes or social posts. Smishing (SMS phishing) and Quishing (QR code phishing) are on the rise, bypassing traditional email spam filters."
            />

            <Section 
              id="creative"
              icon={Lock}
              title="Protecting Creative Work"
              content="For artists and creators, AI scraping is a major concern. Tools like 'Glaze' and 'Nightshade' add invisible noise to your images that disrupt AI training models without affecting visual quality for humans. Watermarking and lower-resolution previews remain effective deterrents for casual theft."
            />
          </main>

          {/* Sidebar */}
          <aside className="space-y-8">
            <div className="sticky top-24">
              <div className="bg-secondary/50 backdrop-blur-md rounded-xl p-6 border border-primary/20 shadow-lg">
                <h3 className="text-lg font-bold mb-4 flex items-center gap-2">
                  <CheckCircle className="text-primary w-5 h-5" />
                  Quick Tips Checklist
                </h3>
                <ul className="space-y-3">
                  {[
                    "Use a password manager",
                    "Enable 2FA everywhere",
                    "Verify urgent requests",
                    "Don't click SMS links",
                    "Update software weekly"
                  ].map((tip, i) => (
                    <li key={i} className="flex items-start gap-3 text-sm text-muted-foreground">
                      <div className="w-1.5 h-1.5 rounded-full bg-primary mt-1.5 shrink-0" />
                      {tip}
                    </li>
                  ))}
                </ul>
              </div>

              <Button 
                onClick={scrollToTop}
                variant="outline" 
                className="w-full mt-4 border-white/10 hover:bg-white/5"
              >
                <ArrowUp className="w-4 h-4 mr-2" />
                Back to Top
              </Button>
            </div>
          </aside>

        </div>
      </div>
    </div>
  );
}

function Section({ icon: Icon, title, content, id }: any) {
  return (
    <motion.section 
      id={id}
      initial={{ opacity: 0, y: 20 }}
      whileInView={{ opacity: 1, y: 0 }}
      viewport={{ once: true }}
      transition={{ duration: 0.5 }}
      className="bg-card/50 rounded-2xl p-8 border border-white/5"
    >
      <div className="flex items-center gap-4 mb-6">
        <div className="p-3 rounded-lg bg-primary/10 text-primary">
          <Icon className="w-8 h-8" />
        </div>
        <h2 className="text-2xl font-bold font-display">{title}</h2>
      </div>
      <p className="text-muted-foreground leading-loose text-lg">
        {content}
      </p>
    </motion.section>
  );
}
