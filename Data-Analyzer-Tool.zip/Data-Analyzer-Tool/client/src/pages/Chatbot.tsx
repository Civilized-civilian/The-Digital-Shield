import { Navbar } from "@/components/Navbar";
import { useSessionId, useChatHistory, useSendMessage } from "@/hooks/use-chat";
import { useState, useRef, useEffect } from "react";
import { Send, Bot, User, Loader2, Sparkles } from "lucide-react";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { ScrollArea } from "@/components/ui/scroll-area";
import { motion, AnimatePresence } from "framer-motion";
import type { ChatMessage } from "@shared/schema";

export default function Chatbot() {
  const sessionId = useSessionId();
  const { data: history, isLoading: isLoadingHistory } = useChatHistory(sessionId);
  const { mutate: sendMessage, isPending } = useSendMessage();
  const [input, setInput] = useState("");
  const scrollRef = useRef<HTMLDivElement>(null);

  // Auto-scroll to bottom
  useEffect(() => {
    if (scrollRef.current) {
      scrollRef.current.scrollIntoView({ behavior: "smooth" });
    }
  }, [history, isPending]);

  const handleSend = () => {
    if (!input.trim() || isPending) return;
    sendMessage(
      { message: input, sessionId },
      { onSuccess: () => setInput("") }
    );
  };

  const handleKeyDown = (e: React.KeyboardEvent) => {
    if (e.key === "Enter" && !e.shiftKey) {
      e.preventDefault();
      handleSend();
    }
  };

  return (
    <div className="min-h-screen bg-background flex flex-col">
      <Navbar />
      
      <main className="flex-1 container mx-auto px-4 py-8 flex flex-col h-[calc(100vh-64px)]">
        <div className="flex items-center gap-3 mb-6">
          <div className="p-3 rounded-xl bg-primary/10 border border-primary/20">
            <Bot className="w-6 h-6 text-primary" />
          </div>
          <div>
            <h1 className="text-2xl font-bold font-display">Security Assistant</h1>
            <p className="text-sm text-muted-foreground flex items-center gap-2">
              <span className="w-2 h-2 rounded-full bg-green-500 animate-pulse" />
              Online • AI Prototype
            </p>
          </div>
        </div>

        <div className="flex-1 bg-secondary/30 rounded-2xl border border-white/10 flex flex-col overflow-hidden shadow-2xl relative">
          {/* Chat Area */}
          <ScrollArea className="flex-1 p-6">
            <div className="space-y-6">
              {/* Welcome Message */}
              <MessageBubble 
                message={{
                  id: -1,
                  message: "Hello! I am IdentityShield AI. Ask me about phishing, password security, or how to secure your accounts.",
                  isBot: true,
                  sessionId: "",
                  createdAt: null
                }} 
              />

              {isLoadingHistory && (
                <div className="flex justify-center py-8">
                  <Loader2 className="w-8 h-8 animate-spin text-primary" />
                </div>
              )}

              {history?.map((msg) => (
                <MessageBubble key={msg.id} message={msg} />
              ))}
              
              {isPending && (
                <div className="flex justify-start">
                  <div className="bg-secondary/80 rounded-2xl rounded-tl-sm px-6 py-4 flex items-center gap-2">
                    <span className="w-2 h-2 bg-primary/50 rounded-full animate-bounce" style={{ animationDelay: "0ms" }} />
                    <span className="w-2 h-2 bg-primary/50 rounded-full animate-bounce" style={{ animationDelay: "150ms" }} />
                    <span className="w-2 h-2 bg-primary/50 rounded-full animate-bounce" style={{ animationDelay: "300ms" }} />
                  </div>
                </div>
              )}
              
              <div ref={scrollRef} />
            </div>
          </ScrollArea>

          {/* Input Area */}
          <div className="p-4 bg-background/50 border-t border-white/5 backdrop-blur-sm">
            <div className="flex gap-2 max-w-4xl mx-auto">
              <Input
                value={input}
                onChange={(e) => setInput(e.target.value)}
                onKeyDown={handleKeyDown}
                placeholder="Ask about digital safety..."
                className="bg-secondary/50 border-white/10 focus:border-primary/50 text-foreground placeholder:text-muted-foreground/50 h-12 rounded-xl"
              />
              <Button 
                onClick={handleSend} 
                disabled={isPending || !input.trim()}
                size="icon"
                className="h-12 w-12 rounded-xl bg-primary hover:bg-primary/90 text-primary-foreground shadow-lg shadow-primary/20"
              >
                {isPending ? <Loader2 className="w-5 h-5 animate-spin" /> : <Send className="w-5 h-5" />}
              </Button>
            </div>
            <div className="text-center mt-2">
              <p className="text-xs text-muted-foreground/50">
                AI may produce inaccurate information. Verify critical security advice.
              </p>
            </div>
          </div>
        </div>
      </main>
    </div>
  );
}

function MessageBubble({ message }: { message: ChatMessage }) {
  const isBot = message.isBot;
  
  return (
    <motion.div 
      initial={{ opacity: 0, y: 10, scale: 0.95 }}
      animate={{ opacity: 1, y: 0, scale: 1 }}
      className={`flex gap-4 ${isBot ? 'justify-start' : 'justify-end'}`}
    >
      {isBot && (
        <div className="w-8 h-8 rounded-full bg-primary/20 flex items-center justify-center shrink-0 border border-primary/30 mt-1">
          <Bot className="w-4 h-4 text-primary" />
        </div>
      )}
      
      <div className={`max-w-[80%] rounded-2xl px-6 py-4 shadow-sm text-sm leading-relaxed ${
        isBot 
          ? 'bg-secondary/80 text-foreground rounded-tl-sm border border-white/5' 
          : 'bg-primary text-primary-foreground rounded-tr-sm font-medium shadow-[0_0_15px_rgba(100,255,218,0.2)]'
      }`}>
        {message.message}
      </div>

      {!isBot && (
        <div className="w-8 h-8 rounded-full bg-secondary flex items-center justify-center shrink-0 border border-white/10 mt-1">
          <User className="w-4 h-4 text-muted-foreground" />
        </div>
      )}
    </motion.div>
  );
}
