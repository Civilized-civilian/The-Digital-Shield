import { Link } from "wouter";
import { Navbar } from "@/components/Navbar";
import { Button } from "@/components/ui/button";
import { Shield, Lock, Bot, Play, Fingerprint, Eye, ArrowRight, Activity } from "lucide-react";
import { motion } from "framer-motion";

export default function Home() {
  return (
    <div className="min-h-screen bg-background text-foreground cyber-grid">
      <Navbar />
      
      {/* Hero Section */}
      <section className="relative pt-20 pb-32 px-4 overflow-hidden">
        <div className="absolute top-0 left-1/2 -translate-x-1/2 w-[1000px] h-[500px] bg-primary/10 rounded-full blur-[120px] -z-10" />
        
        <div className="container mx-auto max-w-5xl text-center">
          <motion.div
            initial={{ opacity: 0, y: 20 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ duration: 0.6 }}
          >
            <div className="inline-flex items-center gap-2 px-3 py-1 rounded-full bg-primary/10 text-primary text-xs font-mono mb-6 border border-primary/20">
              <span className="relative flex h-2 w-2">
                <span className="animate-ping absolute inline-flex h-full w-full rounded-full bg-primary opacity-75"></span>
                <span className="relative inline-flex rounded-full h-2 w-2 bg-primary"></span>
              </span>
              System Secured
            </div>
            
            <h1 className="text-5xl md:text-7xl font-bold font-display tracking-tight mb-6 bg-clip-text text-transparent bg-gradient-to-r from-white via-primary/50 to-white text-glow">
              Protect Your Digital Self
            </h1>
            
            <p className="text-lg md:text-xl text-muted-foreground max-w-2xl mx-auto mb-10 leading-relaxed">
              An AI-powered toolkit to defend your identity against modern threats.
              Learn, simulate attacks, and get real-time protection advice.
            </p>
            
            <div className="flex flex-col sm:flex-row items-center justify-center gap-4">
              <Link href="/chatbot">
                <Button size="lg" className="h-12 px-8 bg-primary text-primary-foreground hover:bg-primary/90 rounded-full font-bold shadow-[0_0_20px_rgba(100,255,218,0.3)] hover:shadow-[0_0_30px_rgba(100,255,218,0.5)] transition-all">
                  <Bot className="mr-2 w-5 h-5" />
                  Launch AI Assistant
                </Button>
              </Link>
              <Link href="/game">
                <Button size="lg" variant="outline" className="h-12 px-8 rounded-full border-white/10 hover:bg-white/5 hover:text-white transition-all">
                  <Play className="mr-2 w-5 h-5" />
                  Play Detective
                </Button>
              </Link>
            </div>
          </motion.div>
        </div>
      </section>

      {/* Features Grid */}
      <section className="py-24 bg-black/20 relative">
        <div className="container mx-auto px-4 lg:px-8">
          <div className="grid md:grid-cols-3 gap-8">
            <FeatureCard 
              icon={Bot}
              title="AI Security Assistant"
              description="Interactive chat bot trained on the latest cybersecurity protocols to answer your questions instantly."
              link="/chatbot"
              color="text-primary"
            />
            <FeatureCard 
              icon={Shield}
              title="Phishing Detective"
              description="Test your skills in our interactive game. Can you spot the scam before it's too late?"
              link="/game"
              color="text-blue-400"
            />
            <FeatureCard 
              icon={Eye}
              title="Deepfake Awareness"
              description="Learn how to identify AI-generated impersonations and protect your biometric data."
              link="/learn"
              color="text-purple-400"
            />
          </div>
        </div>
      </section>

      {/* Stats / Trust Section */}
      <section className="py-20 border-t border-white/5">
        <div className="container mx-auto px-4">
          <div className="grid grid-cols-2 md:grid-cols-4 gap-8 text-center">
            <Stat label="Scams Analyzed" value="10k+" />
            <Stat label="Users Protected" value="50k+" />
            <Stat label="Threats Blocked" value="99.9%" />
            <Stat label="Uptime" value="24/7" />
          </div>
        </div>
      </section>
    </div>
  );
}

function FeatureCard({ icon: Icon, title, description, link, color }: any) {
  return (
    <Link href={link}>
      <motion.div 
        whileHover={{ y: -5 }}
        className="group p-8 rounded-2xl bg-secondary/30 border border-white/5 hover:border-primary/30 transition-all duration-300 cursor-pointer h-full relative overflow-hidden"
      >
        <div className={`absolute top-0 right-0 p-32 bg-${color.split('-')[1]}-500/5 rounded-full blur-3xl -mr-16 -mt-16 transition-opacity group-hover:opacity-100 opacity-50`} />
        
        <div className={`w-12 h-12 rounded-lg bg-background/50 flex items-center justify-center mb-6 border border-white/5 group-hover:border-primary/50 transition-colors ${color}`}>
          <Icon className="w-6 h-6" />
        </div>
        
        <h3 className="text-xl font-bold mb-3 group-hover:text-primary transition-colors">{title}</h3>
        <p className="text-muted-foreground leading-relaxed mb-6">
          {description}
        </p>
        
        <div className="flex items-center text-sm font-medium text-primary opacity-0 group-hover:opacity-100 transition-all transform translate-x-[-10px] group-hover:translate-x-0">
          Try it now <ArrowRight className="ml-1 w-4 h-4" />
        </div>
      </motion.div>
    </Link>
  );
}

function Stat({ label, value }: { label: string, value: string }) {
  return (
    <div>
      <div className="text-3xl md:text-4xl font-bold font-mono text-white mb-2">{value}</div>
      <div className="text-sm text-muted-foreground uppercase tracking-widest font-semibold">{label}</div>
    </div>
  );
}
