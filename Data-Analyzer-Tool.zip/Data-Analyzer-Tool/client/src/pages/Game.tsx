import { Navbar } from "@/components/Navbar";
import { useQuestions, useCheckAnswer } from "@/hooks/use-game";
import { useState, useEffect } from "react";
import { GameCard } from "@/components/GameCard";
import { Button } from "@/components/ui/button";
import { Trophy, RefreshCw, AlertCircle, Loader2 } from "lucide-react";
import { motion, AnimatePresence } from "framer-motion";
import type { GameQuestion } from "@shared/schema";

export default function Game() {
  const { data: questions, isLoading, isError, refetch } = useQuestions();
  const { mutate: checkAnswer, isPending } = useCheckAnswer();
  
  const [currentIndex, setCurrentIndex] = useState(0);
  const [score, setScore] = useState(0);
  const [result, setResult] = useState<{ correct: boolean; explanation: string } | null>(null);
  const [gameOver, setGameOver] = useState(false);

  // When result is shown, wait a bit or let user click next?
  // Let's add a "Next Question" button that appears after answering

  const handleAnswer = (userGuessedScam: boolean) => {
    if (!questions) return;
    const currentQuestion = questions[currentIndex];
    
    checkAnswer(
      { questionId: currentQuestion.id, userGuessedScam },
      {
        onSuccess: (data) => {
          setResult(data);
          if (data.correct) setScore(s => s + 1);
        }
      }
    );
  };

  const nextQuestion = () => {
    setResult(null);
    if (questions && currentIndex < questions.length - 1) {
      setCurrentIndex(prev => prev + 1);
    } else {
      setGameOver(true);
    }
  };

  const restartGame = () => {
    setScore(0);
    setCurrentIndex(0);
    setGameOver(false);
    setResult(null);
    refetch(); // Maybe fetch new shuffled questions if API supported it
  };

  if (isLoading) {
    return (
      <div className="min-h-screen bg-background flex flex-col">
        <Navbar />
        <div className="flex-1 flex items-center justify-center">
          <Loader2 className="w-12 h-12 text-primary animate-spin" />
        </div>
      </div>
    );
  }

  if (isError || !questions || questions.length === 0) {
    return (
      <div className="min-h-screen bg-background flex flex-col">
        <Navbar />
        <div className="flex-1 flex flex-col items-center justify-center gap-4 text-center px-4">
          <AlertCircle className="w-16 h-16 text-destructive" />
          <h2 className="text-2xl font-bold">Failed to load mission</h2>
          <Button onClick={() => refetch()} variant="outline">Retry Connection</Button>
        </div>
      </div>
    );
  }

  return (
    <div className="min-h-screen bg-background cyber-grid flex flex-col">
      <Navbar />
      
      <main className="flex-1 container mx-auto px-4 py-12 flex flex-col items-center">
        
        {/* Header / Scoreboard */}
        <div className="w-full max-w-2xl flex items-center justify-between mb-8 bg-secondary/50 p-4 rounded-xl border border-white/5 backdrop-blur-md">
          <div className="flex flex-col">
            <span className="text-xs text-muted-foreground uppercase tracking-widest">Mission Progress</span>
            <span className="text-2xl font-mono font-bold text-foreground">
              {currentIndex + 1} <span className="text-muted-foreground/50">/</span> {questions.length}
            </span>
          </div>
          
          <div className="flex items-center gap-3">
            <div className="text-right">
              <span className="block text-xs text-muted-foreground uppercase tracking-widest">Current Score</span>
              <span className="block text-2xl font-mono font-bold text-primary">{score}00</span>
            </div>
            <Trophy className="w-8 h-8 text-yellow-500" />
          </div>
        </div>

        {/* Game Area */}
        <AnimatePresence mode="wait">
          {!gameOver ? (
            <div className="w-full flex flex-col items-center gap-6">
              <GameCard 
                key={currentIndex}
                question={questions[currentIndex]}
                onAnswer={handleAnswer}
                result={result}
                isPending={isPending}
              />
              
              {result && (
                <motion.div
                  initial={{ opacity: 0, y: 10 }}
                  animate={{ opacity: 1, y: 0 }}
                >
                  <Button 
                    onClick={nextQuestion} 
                    size="lg" 
                    className="h-14 px-8 text-lg font-bold bg-primary text-primary-foreground hover:bg-primary/90 shadow-lg shadow-primary/25 rounded-full"
                  >
                    {currentIndex === questions.length - 1 ? "Finish Mission" : "Next Scenario"}
                  </Button>
                </motion.div>
              )}
            </div>
          ) : (
            <motion.div 
              initial={{ scale: 0.9, opacity: 0 }}
              animate={{ scale: 1, opacity: 1 }}
              className="w-full max-w-lg text-center bg-secondary/80 p-12 rounded-3xl border border-primary/20 backdrop-blur-xl shadow-2xl"
            >
              <Trophy className="w-24 h-24 text-yellow-400 mx-auto mb-6 drop-shadow-[0_0_15px_rgba(250,204,21,0.5)]" />
              <h2 className="text-4xl font-bold font-display mb-2">Mission Complete!</h2>
              <p className="text-muted-foreground mb-8">You successfully analyzed the threats.</p>
              
              <div className="text-6xl font-mono font-bold text-primary mb-8 text-glow">
                {score}/{questions.length}
              </div>
              
              <div className="flex flex-col gap-3">
                <Button onClick={restartGame} size="lg" className="w-full">
                  <RefreshCw className="mr-2 w-4 h-4" />
                  Replay Mission
                </Button>
                <Button variant="ghost" onClick={() => window.location.href = '/'} className="w-full">
                  Return to Base
                </Button>
              </div>
            </motion.div>
          )}
        </AnimatePresence>

      </main>
    </div>
  );
}
