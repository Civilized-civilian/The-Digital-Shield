import { motion } from "framer-motion";
import { Mail, MessageSquare, AlertTriangle, CheckCircle, XCircle } from "lucide-react";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import type { GameQuestion } from "@shared/schema";

interface GameCardProps {
  question: GameQuestion;
  onAnswer: (isScam: boolean) => void;
  result: { correct: boolean; explanation: string } | null;
  isPending: boolean;
}

export function GameCard({ question, onAnswer, result, isPending }: GameCardProps) {
  const isEmail = question.type === 'email';

  return (
    <motion.div
      initial={{ opacity: 0, y: 20 }}
      animate={{ opacity: 1, y: 0 }}
      exit={{ opacity: 0, y: -20 }}
      transition={{ duration: 0.3 }}
      className="w-full max-w-2xl mx-auto"
    >
      <Card className="border-border/50 bg-secondary/50 backdrop-blur-sm overflow-hidden shadow-xl">
        <div className={`h-2 w-full ${result ? (result.correct ? 'bg-green-500' : 'bg-red-500') : 'bg-primary/20'}`} />
        
        <CardHeader className="pb-4">
          <div className="flex items-center justify-between">
            <div className="flex items-center gap-3">
              <div className={`p-2 rounded-lg ${isEmail ? 'bg-blue-500/10 text-blue-400' : 'bg-green-500/10 text-green-400'}`}>
                {isEmail ? <Mail className="w-5 h-5" /> : <MessageSquare className="w-5 h-5" />}
              </div>
              <CardTitle className="text-lg font-medium text-muted-foreground">
                Incoming {isEmail ? 'Email' : 'Message'}
              </CardTitle>
            </div>
            <Badge variant="outline" className="font-mono text-xs uppercase tracking-wider bg-background/50">
              Scenario #{question.id}
            </Badge>
          </div>
        </CardHeader>

        <CardContent className="space-y-6">
          <div className="bg-background rounded-xl p-6 border border-border font-mono text-sm leading-relaxed relative">
            <div className="absolute top-0 left-0 w-full h-1 bg-gradient-to-r from-transparent via-primary/20 to-transparent opacity-50" />
            {question.content}
          </div>

          {!result ? (
            <div className="grid grid-cols-2 gap-4 pt-2">
              <button
                onClick={() => onAnswer(false)}
                disabled={isPending}
                className="group relative overflow-hidden rounded-xl bg-green-500/10 border border-green-500/20 p-4 hover:bg-green-500/20 hover:border-green-500/50 transition-all duration-300 disabled:opacity-50"
              >
                <div className="flex flex-col items-center gap-2 relative z-10">
                  <CheckCircle className="w-8 h-8 text-green-500 mb-1 group-hover:scale-110 transition-transform" />
                  <span className="font-bold text-green-400">Legitimate</span>
                  <span className="text-xs text-green-500/60">This looks safe</span>
                </div>
              </button>

              <button
                onClick={() => onAnswer(true)}
                disabled={isPending}
                className="group relative overflow-hidden rounded-xl bg-red-500/10 border border-red-500/20 p-4 hover:bg-red-500/20 hover:border-red-500/50 transition-all duration-300 disabled:opacity-50"
              >
                <div className="flex flex-col items-center gap-2 relative z-10">
                  <AlertTriangle className="w-8 h-8 text-red-500 mb-1 group-hover:scale-110 transition-transform" />
                  <span className="font-bold text-red-400">Scam / Phishing</span>
                  <span className="text-xs text-red-500/60">Report as suspicious</span>
                </div>
              </button>
            </div>
          ) : (
            <motion.div
              initial={{ opacity: 0, scale: 0.95 }}
              animate={{ opacity: 1, scale: 1 }}
              className={`rounded-xl p-6 border ${
                result.correct 
                  ? 'bg-green-500/10 border-green-500/30' 
                  : 'bg-red-500/10 border-red-500/30'
              }`}
            >
              <div className="flex items-start gap-4">
                <div className={`p-2 rounded-full shrink-0 ${result.correct ? 'bg-green-500/20 text-green-400' : 'bg-red-500/20 text-red-400'}`}>
                  {result.correct ? <CheckCircle className="w-6 h-6" /> : <XCircle className="w-6 h-6" />}
                </div>
                <div>
                  <h4 className={`text-lg font-bold mb-1 ${result.correct ? 'text-green-400' : 'text-red-400'}`}>
                    {result.correct ? 'Correct Analysis!' : 'Incorrect Analysis'}
                  </h4>
                  <p className="text-sm text-foreground/80 leading-relaxed">
                    {result.explanation}
                  </p>
                </div>
              </div>
            </motion.div>
          )}
        </CardContent>
      </Card>
    </motion.div>
  );
}
